<?php   
defined('C5_EXECUTE') or die("Доступ запрещен.");

$this->inc('page_list_form.php');

?>